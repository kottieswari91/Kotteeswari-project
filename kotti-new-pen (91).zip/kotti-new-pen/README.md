# Kotti new pen

A Pen created on CodePen.

Original URL: [https://codepen.io/Kotteeswari-Kotteeswari/pen/dPYrPEG](https://codepen.io/Kotteeswari-Kotteeswari/pen/dPYrPEG).

